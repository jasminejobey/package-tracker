import { useState, useEffect, useCallback } from "react";

const SCAN_SYSTEM = `You are a package tracking assistant. Search the user's Gmail inbox for emails containing package tracking numbers or tracking links from carriers like UPS, FedEx, USPS, DHL, Amazon, OnTrac, LaserShip, etc. from the last 90 days.

For each tracking number or tracking link found, return a JSON array. Each item must have:
- id: unique string
- company: retailer/sender name (e.g. "Nordstrom", "Amazon", "Zara")
- carrier: shipping carrier (e.g. "UPS", "FedEx", "USPS", "DHL", "Amazon Logistics")
- trackingNumber: the tracking number string
- trackingUrl: full tracking URL if found, otherwise construct from tracking number
- emailSubject: the email subject
- emailDate: ISO date string

Return ONLY a valid JSON array. No markdown, no explanation. If nothing found, return [].`;

const statusSystem = (carrier, trackingNumber, trackingUrl) =>
  `You are a package tracking assistant. Use web search to look up the current status of this shipment:
Carrier: ${carrier}
Tracking Number: ${trackingNumber}
Tracking URL: ${trackingUrl}

Return ONLY a JSON object with:
- status: one of "Delivered", "Out for Delivery", "In Transit", "Pending", "Exception"
- estimatedDelivery: readable string (e.g. "Today by 8pm", "Apr 2") or null
- lastUpdate: most recent tracking event as short string
- deliveredDate: ISO date string if delivered, else null

Return ONLY valid JSON. No markdown, no explanation.`;

function parseJSON(text) {
  try {
    const clean = text.replace(/```json|```/g, "").trim();
    const s = clean.search(/[[\{]/);
    const e = Math.max(clean.lastIndexOf("]"), clean.lastIndexOf("}")) + 1;
    return JSON.parse(clean.slice(s, e));
  } catch { return null; }
}

function shouldRemove(pkg) {
  if (pkg.status !== "Delivered" || !pkg.deliveredDate) return false;
  return new Date() > new Date(new Date(pkg.deliveredDate).getTime() + 2 * 864e5);
}

async function callClaude(messages, system, useSearch = false) {
  const body = {
    model: "claude-sonnet-4-20250514",
    max_tokens: 1000,
    system,
    messages,
    mcp_servers: [{ type: "url", url: "https://gmail.mcp.claude.com/mcp", name: "gmail-mcp" }],
  };
  if (useSearch) body.tools = [{ type: "web_search_20250305", name: "web_search" }];

  const res = await fetch("/api/claude", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  return (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
}

const STATUS_COLORS = {
  "Delivered":        { bg: "#eaf3de", text: "#27500a", border: "#97c459" },
  "In Transit":       { bg: "#e6f1fb", text: "#0c447c", border: "#85b7eb" },
  "Out for Delivery": { bg: "#faeeda", text: "#633806", border: "#ef9f27" },
  "Exception":        { bg: "#fcebeb", text: "#791f1f", border: "#f09595" },
  "Pending":          { bg: "#f1efe8", text: "#5f5e5a", border: "#b4b2a9" },
};

function Badge({ status }) {
  const c = STATUS_COLORS[status] || STATUS_COLORS["Pending"];
  return (
    <span style={{
      display: "inline-block", padding: "3px 10px", borderRadius: 6,
      fontSize: 12, fontWeight: 500, background: c.bg, color: c.text,
      border: `1px solid ${c.border}`, whiteSpace: "nowrap",
    }}>
      {status}
    </span>
  );
}

function Spinner({ size = 14, color = "#378add" }) {
  return (
    <span style={{
      display: "inline-block", width: size, height: size, borderRadius: "50%",
      border: `2px solid #e0ddd6`, borderTopColor: color,
      animation: "spin 0.8s linear infinite", verticalAlign: "middle", flexShrink: 0,
    }} />
  );
}

export default function App() {
  const [packages, setPackages] = useState([]);
  const [phase, setPhase] = useState("idle");
  const [statusMsg, setStatusMsg] = useState("");
  const [progress, setProgress] = useState({ n: 0, total: 0 });
  const [filter, setFilter] = useState("all");
  const [lastScanned, setLastScanned] = useState(null);
  const [error, setError] = useState("");

  const scan = useCallback(async () => {
    setPhase("scanning");
    setError("");
    setPackages([]);
    setStatusMsg("Scanning Gmail for tracking numbers…");

    try {
      const raw = await callClaude(
        [{ role: "user", content: "Search my Gmail for shipping confirmation emails with tracking numbers from the last 90 days. Return the JSON array." }],
        SCAN_SYSTEM
      );

      const found = parseJSON(raw);
      if (!found || !Array.isArray(found) || found.length === 0) {
        setStatusMsg("No tracking numbers found in recent emails.");
        setPhase("done");
        setLastScanned(new Date());
        return;
      }

      setPhase("fetching");
      setProgress({ n: 0, total: found.length });
      const results = [];

      for (let i = 0; i < found.length; i++) {
        const pkg = found[i];
        setStatusMsg(`Checking ${pkg.company || pkg.carrier} — ${pkg.trackingNumber}`);
        setProgress({ n: i + 1, total: found.length });

        try {
          const statusRaw = await callClaude(
            [{ role: "user", content: `Look up status for tracking number ${pkg.trackingNumber} from ${pkg.carrier}.` }],
            statusSystem(pkg.carrier, pkg.trackingNumber, pkg.trackingUrl),
            true
          );
          const sd = parseJSON(statusRaw) || {};
          const full = {
            ...pkg,
            status: sd.status || "Pending",
            estimatedDelivery: sd.estimatedDelivery || "—",
            lastUpdate: sd.lastUpdate || "",
            deliveredDate: sd.deliveredDate || null,
          };
          if (!shouldRemove(full)) {
            results.push(full);
            setPackages([...results]);
          }
        } catch {
          results.push({ ...pkg, status: "Pending", estimatedDelivery: "—", lastUpdate: "" });
          setPackages([...results]);
        }
      }

      setPhase("done");
      setLastScanned(new Date());
      setStatusMsg(`${results.length} shipment${results.length !== 1 ? "s" : ""} found`);
    } catch (e) {
      setPhase("error");
      setError("Could not connect. Check that your ANTHROPIC_API_KEY is set in Railway.");
    }
  }, []);

  useEffect(() => { scan(); }, [scan]);

  const filtered = packages.filter((p) => {
    if (filter === "active") return p.status !== "Delivered";
    if (filter === "delivered") return p.status === "Delivered";
    return true;
  });

  const counts = {
    all: packages.length,
    active: packages.filter((p) => p.status !== "Delivered").length,
    delivered: packages.filter((p) => p.status === "Delivered").length,
  };

  const isLoading = phase === "scanning" || phase === "fetching";

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "48px 24px" }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 32, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 28, fontWeight: 500, marginBottom: 4, letterSpacing: "-0.5px" }}>Package tracker</h1>
          <p style={{ fontSize: 13, color: "#888780" }}>
            {lastScanned
              ? `Last scanned ${lastScanned.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} · ${statusMsg}`
              : isLoading ? statusMsg : "Ready"}
          </p>
        </div>
        <button
          onClick={scan}
          disabled={isLoading}
          style={{
            display: "flex", alignItems: "center", gap: 8, padding: "9px 18px",
            background: "#fff", border: "1px solid #d3d1c7", borderRadius: 8,
            fontSize: 13, fontWeight: 500, cursor: isLoading ? "not-allowed" : "pointer",
            opacity: isLoading ? 0.5 : 1, fontFamily: "'DM Sans', sans-serif",
            color: "#1a1a18",
          }}
        >
          {isLoading ? <Spinner size={13} /> : <span style={{ fontSize: 15 }}>↺</span>}
          {isLoading ? "Scanning…" : "Refresh"}
        </button>
      </div>

      {/* Metric cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 28 }}>
        {[
          { label: "Total shipments", val: counts.all },
          { label: "In transit", val: counts.active },
          { label: "Delivered", val: counts.delivered },
        ].map(({ label, val }) => (
          <div key={label} style={{ background: "#fff", border: "1px solid #e8e6df", borderRadius: 10, padding: "16px 20px" }}>
            <p style={{ fontSize: 12, color: "#888780", marginBottom: 6 }}>{label}</p>
            <p style={{ fontSize: 26, fontWeight: 500 }}>{val || "—"}</p>
          </div>
        ))}
      </div>

      {/* Progress bar */}
      {isLoading && (
        <div style={{
          background: "#fff", border: "1px solid #e8e6df", borderRadius: 8,
          padding: "12px 16px", marginBottom: 20, display: "flex",
          alignItems: "center", gap: 10, fontSize: 13, color: "#5f5e5a",
        }}>
          <Spinner />
          <span>{statusMsg}</span>
          {phase === "fetching" && progress.total > 0 && (
            <span style={{ marginLeft: "auto", fontSize: 12, color: "#b4b2a9" }}>
              {progress.n}/{progress.total}
            </span>
          )}
        </div>
      )}

      {/* Error */}
      {error && (
        <div style={{
          background: "#fcebeb", border: "1px solid #f09595", borderRadius: 8,
          padding: "12px 16px", marginBottom: 20, fontSize: 13, color: "#791f1f",
        }}>
          {error}
        </div>
      )}

      {/* Filters */}
      {packages.length > 0 && (
        <div style={{ display: "flex", gap: 4, marginBottom: 16 }}>
          {["all", "active", "delivered"].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              style={{
                padding: "5px 14px", borderRadius: 7, fontSize: 13,
                fontFamily: "'DM Sans', sans-serif", cursor: "pointer",
                background: filter === f ? "#fff" : "transparent",
                border: filter === f ? "1px solid #d3d1c7" : "1px solid transparent",
                color: filter === f ? "#1a1a18" : "#888780",
                fontWeight: filter === f ? 500 : 400,
              }}
            >
              {f === "all" ? "All" : f === "active" ? "In transit" : "Delivered"}
              <span style={{ marginLeft: 5, fontSize: 11, color: "#b4b2a9" }}>{counts[f]}</span>
            </button>
          ))}
        </div>
      )}

      {/* Table */}
      {filtered.length > 0 ? (
        <div style={{ background: "#fff", border: "1px solid #e8e6df", borderRadius: 12, overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", tableLayout: "fixed", fontSize: 13 }}>
            <colgroup>
              <col style={{ width: "22%" }} />
              <col style={{ width: "16%" }} />
              <col style={{ width: "24%" }} />
              <col style={{ width: "22%" }} />
              <col style={{ width: "16%" }} />
            </colgroup>
            <thead>
              <tr style={{ background: "#f7f6f3", borderBottom: "1px solid #e8e6df" }}>
                {["Company", "Carrier", "Tracking", "Expected delivery", "Status"].map((h) => (
                  <th key={h} style={{ padding: "10px 16px", textAlign: "left", fontWeight: 500, fontSize: 12, color: "#888780", letterSpacing: "0.02em" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((pkg, i) => (
                <tr key={pkg.id || i} className="fade-in" style={{ borderBottom: i < filtered.length - 1 ? "1px solid #f1efe8" : "none" }}>
                  <td style={{ padding: "13px 16px", fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {pkg.company || "Unknown"}
                  </td>
                  <td style={{ padding: "13px 16px", color: "#888780", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {pkg.carrier}
                  </td>
                  <td style={{ padding: "13px 16px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {pkg.trackingUrl ? (
                      <a href={pkg.trackingUrl} target="_blank" rel="noreferrer"
                        style={{ color: "#185fa5", fontFamily: "'DM Mono', monospace", fontSize: 12 }}>
                        {pkg.trackingNumber}
                      </a>
                    ) : (
                      <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 12, color: "#888780" }}>{pkg.trackingNumber}</span>
                    )}
                  </td>
                  <td style={{ padding: "13px 16px", overflow: "hidden" }}>
                    <span style={{ display: "block", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {pkg.estimatedDelivery || "—"}
                    </span>
                    {pkg.lastUpdate && (
                      <span style={{ fontSize: 11, color: "#b4b2a9", display: "block", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", marginTop: 2 }}>
                        {pkg.lastUpdate}
                      </span>
                    )}
                  </td>
                  <td style={{ padding: "13px 16px" }}>
                    <Badge status={pkg.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : phase === "done" ? (
        <div style={{ textAlign: "center", padding: "60px 20px", color: "#b4b2a9" }}>
          <div style={{ width: 48, height: 48, border: "1.5px solid #e8e6df", borderRadius: 10, margin: "0 auto 14px", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#d3d1c7" strokeWidth="1.5">
              <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
            </svg>
          </div>
          <p style={{ fontSize: 14 }}>No active shipments found.</p>
        </div>
      ) : null}

      {phase === "done" && packages.length > 0 && (
        <p style={{ fontSize: 11, color: "#b4b2a9", marginTop: 14, textAlign: "center" }}>
          Delivered packages are automatically removed 2 days after delivery.
        </p>
      )}
    </div>
  );
}
